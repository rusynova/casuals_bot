pip install -U discord.py
